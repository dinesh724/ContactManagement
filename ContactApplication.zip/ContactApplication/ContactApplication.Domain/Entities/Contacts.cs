﻿using Contact.Domain.Common;
using System;

namespace Contact.Domain.Entities
{
    public class Contacts : BaseEntity
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string FavColour { get; set; }
    }
}
