﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contact.Domain.Common
{
    public class BaseEntity
    {
        public DateTime DateCreated { get; set; }
    }
}
