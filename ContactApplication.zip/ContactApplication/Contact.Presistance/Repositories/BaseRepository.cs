﻿using Contact.Application.Contracts.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Contact.Presistance.Repositories
{
    public class BaseRepository<T> : IAsyncRepository<T> where T : class
    {
        private ContactDbcontext _contactDbContext;

        public BaseRepository(ContactDbcontext ContactsDbContext)
        {
            _contactDbContext = ContactsDbContext;
        }

        public async Task<T> AddAsync(T entity)
        {
            await _contactDbContext.Set<T>().AddAsync(entity);
            await _contactDbContext.SaveChangesAsync();

            return entity;
        }



        public async Task<T> GetByIdAsync(Guid id)
        {
            return await _contactDbContext.Set<T>().FindAsync(id);
        }

        public async Task<IReadOnlyList<T>> ListAllAsync()
        {
            return await _contactDbContext.Set<T>().ToListAsync();
        }

        public async Task UpdateAsync(T entity)
        {
            _contactDbContext.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _contactDbContext.SaveChangesAsync();
        }



        public async Task DeleteAsync(T entity)
        {
            _contactDbContext.Set<T>().Remove(entity);
            await _contactDbContext.SaveChangesAsync();
        }


    }
}
