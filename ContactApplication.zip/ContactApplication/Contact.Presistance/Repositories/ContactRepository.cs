﻿using Contact.Application.Contracts.Persistence;
using Contact.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contact.Presistance.Repositories
{
    public class ContactRepository : BaseRepository<Contacts>, IContactsRepository
    {
        public ContactRepository(ContactDbcontext dbContext) : base(dbContext)
        {

        }
    }
}
