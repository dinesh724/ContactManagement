﻿using Contact.Domain.Common;
using Contact.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Contact.Presistance
{
    public class ContactDbcontext : DbContext
    {
        public ContactDbcontext(DbContextOptions<ContactDbcontext> options)
            : base(options)
        {

        }

        public DbSet<Contacts> Contacts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(ContactDbcontext).Assembly);

            var ContactsGuid = Guid.Parse("5d8bf118-67ef-48f5-b8b5-d596d87375e3");

            modelBuilder.Entity<Contacts>().HasData(
             new Contacts
             {
                 Id = ContactsGuid,
                 FirstName = "Dinesh",
                 LastName = "Yadav",
                 DateOfBirth = DateTime.Now,
                 FavColour = "Blue"
             });

            base.OnModelCreating(modelBuilder);
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            foreach (var entry in ChangeTracker.Entries<BaseEntity>())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.DateCreated = DateTime.Now;
                        break;
                }
            }

            return base.SaveChangesAsync(cancellationToken);
        }
    }
}
