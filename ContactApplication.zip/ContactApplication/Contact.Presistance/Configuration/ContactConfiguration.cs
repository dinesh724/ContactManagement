﻿using Contact.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contact.Presistance.Configuration
{
    public class ContactConfiguration : IEntityTypeConfiguration<Contacts>
    {
        public void Configure(EntityTypeBuilder<Contacts> builder)
        {
            builder.Property(p => p.FirstName)
               .IsRequired();
            builder.Property(p => p.LastName)
               .IsRequired();
            builder.Property(p => p.DateOfBirth)
               .IsRequired();
            builder.Property(p => p.FavColour)
               .IsRequired();
        }
    }
}
