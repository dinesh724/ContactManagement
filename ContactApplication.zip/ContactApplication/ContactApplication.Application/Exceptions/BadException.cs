﻿using System;

namespace Contact.Application.Exceptions
{
    public class BadException : ApplicationException
    {
        public BadException(string message) : base(message)
        {

        }
    }
}
