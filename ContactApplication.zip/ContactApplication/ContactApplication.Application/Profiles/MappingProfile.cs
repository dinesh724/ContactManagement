﻿using AutoMapper;
using Contact.Application.Features.Contact.Commands.CreateContactCommand;
using Contact.Application.Features.Contact.Queries.GetContact;
using Contact.Application.Features.Contact.Queries.GetContactList;
using Contact.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contact.Application.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Contacts, ContactsVm>().ReverseMap();
            CreateMap<Contacts, CreateContactVm>().ReverseMap();
            CreateMap<Contacts, ContactsListVm>().ReverseMap();
        }
    }
}
