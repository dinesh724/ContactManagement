﻿using Contact.Application.Responses;

namespace Contact.Application.Features.Contact.Commands.CreateContactCommand
{
    public class ContactCommandResponse : BaseResponse
    {
        public ContactCommandResponse() : base()
        {

        }

        public CreateContactVm CreatedContact { get; set; }
    }
}
