﻿using MediatR;
using System;

namespace Contact.Application.Features.Contact.Commands.CreateContactCommand
{
    public class CreateContactCommand : IRequest<ContactCommandResponse>
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string FavColour { get; set; }

        public override string ToString()
        {
            return $" Contact  First Name : {FirstName}; Last Name : {LastName}; Date of Birth {DateOfBirth} ; Favourite Colour {FavColour} ";
        }
    }
}
