﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contact.Application.Features.Contact.Commands.CreateContactCommand
{
    public class ContactCommandValidator: AbstractValidator<CreateContactCommand>
    {
        public ContactCommandValidator()
        {
            RuleFor(p => p.FirstName)
           .NotEmpty().WithMessage("{ParameterName} is required");

            RuleFor(p => p.LastName)
                .NotEmpty().WithMessage("{ParameterName} is required");

            RuleFor(p => p.DateOfBirth)
                .NotEmpty().WithMessage("{ParameterName} is required");

            RuleFor(p => p.FavColour)
                .NotEmpty().WithMessage("{ParameterName} is required");
        }

    }
}
