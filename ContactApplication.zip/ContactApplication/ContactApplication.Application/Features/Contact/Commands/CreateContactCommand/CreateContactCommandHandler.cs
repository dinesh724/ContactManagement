﻿using AutoMapper;
using Contact.Application.Contracts.Persistence;
using Contact.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Contact.Application.Features.Contact.Commands.CreateContactCommand
{
    public class CreateContactCommandHandler : IRequestHandler<CreateContactCommand, ContactCommandResponse>
    {
        private IMapper _mapper;
        private IContactsRepository _contactsRepository;

        public CreateContactCommandHandler(IMapper mapper , IContactsRepository contactsRepository)
        {
            _mapper = mapper;
            _contactsRepository = contactsRepository;
        }

        public async Task<ContactCommandResponse> Handle(CreateContactCommand request, CancellationToken cancellationToken)
        {
            // create custom response
            var createCommandResponse = new ContactCommandResponse();

            // create validator
            var validator = new ContactCommandValidator();
            var validationResult = await validator.ValidateAsync(request);

            if (validationResult.Errors.Count > 0)
            {
                createCommandResponse.Success = false;
                createCommandResponse.ValidationErrors = new List<string>();

                foreach (var error in validationResult.Errors)
                {
                    createCommandResponse.ValidationErrors.Add(error.ErrorMessage);
                }
            }

            if (createCommandResponse.Success)
            {
                var contacts = new Contacts()
                {
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    DateOfBirth = request.DateOfBirth,
                    FavColour = request.FavColour
                };

                contacts = await _contactsRepository.AddAsync(contacts);

                createCommandResponse.CreatedContact = _mapper.Map<CreateContactVm>(contacts);
            }

            return createCommandResponse;

        }
    }
}
