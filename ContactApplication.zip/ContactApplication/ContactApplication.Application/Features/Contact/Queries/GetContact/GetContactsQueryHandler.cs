﻿using AutoMapper;
using Contact.Application.Contracts.Persistence;
using Contact.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Contact.Application.Features.Contact.Queries.GetContact
{
    public class GetContactsQueryHandler : IRequestHandler<GetContactsQuery, ContactsVm>
    {
        private IMapper _mapper;
        private IAsyncRepository<Contacts> _contactsRepository;

        public GetContactsQueryHandler(IMapper mapper, IAsyncRepository<Contacts> contactsRepository)
        {
            _mapper = mapper;
            _contactsRepository = contactsRepository;
        }
        public async Task<ContactsVm> Handle(GetContactsQuery request, CancellationToken cancellationToken)
        {
            var ContactDetails = await _contactsRepository.GetByIdAsync(request.Id);

            return _mapper.Map<ContactsVm>(ContactDetails);
        }
    }
}
