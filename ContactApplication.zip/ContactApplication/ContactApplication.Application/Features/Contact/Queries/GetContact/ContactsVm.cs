﻿using System;

namespace Contact.Application.Features.Contact.Queries.GetContact
{
    public class ContactsVm
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string FavColour { get; set; }
    }
}
