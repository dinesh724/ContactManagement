﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contact.Application.Features.Contact.Queries.GetContact
{
   public class GetContactsQuery : IRequest<ContactsVm>
    {
        public Guid Id { get; set; }
    }
}
