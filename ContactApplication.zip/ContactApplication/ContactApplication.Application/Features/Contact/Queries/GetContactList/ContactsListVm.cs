﻿using System;

namespace Contact.Application.Features.Contact.Queries.GetContactList
{
    public class ContactsListVm
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string FavColour { get; set; }
    }
}
