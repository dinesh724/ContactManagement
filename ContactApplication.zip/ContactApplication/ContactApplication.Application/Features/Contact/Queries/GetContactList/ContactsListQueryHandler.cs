﻿using AutoMapper;
using Contact.Application.Contracts.Persistence;
using Contact.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Contact.Application.Features.Contact.Queries.GetContactList
{
    public class ContactsListQueryHandler : IRequestHandler<GetContactsListQuery, List<ContactsListVm>>
    {
        private IMapper _mapper;
        private IAsyncRepository<Contacts> _contactsRepository;

        public ContactsListQueryHandler(IMapper mapper, IAsyncRepository<Contacts> contactsRepository)
        {
            _mapper = mapper;
            _contactsRepository = contactsRepository;
        }
        public async Task<List<ContactsListVm>> Handle(GetContactsListQuery request, CancellationToken cancellationToken)
        {
            var ContactDetails = (await _contactsRepository.ListAllAsync()).OrderBy(x => x.FirstName);

            return _mapper.Map<List<ContactsListVm>>(ContactDetails);
        }
    }
}
