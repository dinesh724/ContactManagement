﻿using MediatR;
using System;
using System.Collections.Generic;

namespace Contact.Application.Features.Contact.Queries.GetContactList
{
    public class GetContactsListQuery : IRequest<List<ContactsListVm>>
    {
        public Guid Id { get; set; }
    }
}
