﻿using Contact.Domain.Entities;

namespace Contact.Application.Contracts.Persistence
{
    public interface IContactsRepository : IAsyncRepository<Contacts>
    {

    }
}
