﻿using Contact.Application.Features.Contact.Commands.CreateContactCommand;
using Contact.Application.Features.Contact.Queries.GetContact;
using Contact.Application.Features.Contact.Queries.GetContactList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Contacts.Api.Controllers
{
    [ApiController]
    [Route("api/contacts")]
    public class ContactsController : ControllerBase
    {
        private static readonly string[] Colours = new[] { "black", "white", "gray", "silver", "maroon", "red", "purple", "fushsia", "green", "lime", "olive", "yellow", "navy", "blue", "teal", "aqua" };

        private IMediator _mediator;

        public ContactsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [Route("GetColours")]
        public IEnumerable<object> GetColours()
        {
            //return Ok(new { colours = "black, white, gray, silver, maroon, red, purple, fushsia, green, lime, olive, yellow, navy, blue, teal, aqua" });

            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new
            {
                Colour = Colours[rng.Next(Colours.Length)],
            })
            .ToArray().Distinct();
        }

        [HttpGet]
        public async Task<ActionResult<List<ContactsListVm>>> GetContacts()
        {
            var Contacts = await _mediator.Send(new GetContactsListQuery());

            if (Contacts == null)
            {
                return NotFound();
            }

            return Ok(Contacts);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<ActionResult<ContactsVm>> GetContact(Guid id)
        {
            var Contact = await _mediator.Send(new GetContactsQuery() { Id = id });

            if (Contact == null)
            {
                return NotFound();
            }

            return Ok(Contact);
        }

        [HttpPost]
        public async Task<ActionResult<ContactCommandResponse>> CreateContact(CreateContactCommand createContactCommand)
        {
            var response = await _mediator.Send(createContactCommand);

            return Ok(response);
        }

    }
}
