import React,{useEffect , useState } from 'react'
import axios from 'axios'
import './Contactform.css';
const BASE_URL = 'https://localhost:44301/api/contacts/GetColours'

const BASE_URL_ForContacts = 'https://localhost:44301/api/contacts'

export default function PostForm() {
    const [colourOptions, setColourOptions] = useState([]) 
    const [contacts, setContacts] = useState([]) 
    const [error, seterror] = useState([]) 

    const[data,setData] = useState({
    "firstName": "",
    "lastName": "",
    "dateOfBirth": "",
    "favColour": ""
})

useEffect(() => {
    fetch(BASE_URL)
      .then(res => res.json())
      .then(data => {setColourOptions(data)})
      .catch((error) => {
        console.log(error)
      });

      fetch(BASE_URL_ForContacts)
      .then(res => res.json())
      .then(data => {setContacts(data)})
      .catch((error) => {
        console.log(error)
      });

  }, [])


 function Submit(e){
    e.preventDefault();
    axios.post("https://localhost:44301/api/contacts/",{
        firstName : data.firstName,
        lastName : data.lastName,
        dateOfBirth : data.dateOfBirth,
        favColour : data.favColour
    })
    .then((response)=>{
        if (response.status === 200){
          
            //alert("Contact saved successfully."); 
            console.log(data.firstName);
         
           let displayData = 
           '\r First Name: ' + data.firstName + ' \r\n ' + 
           'Last Name: ' + data.lastName + ' \r\n ' + 
           'Date Of Birth: ' + data.dateOfBirth + ' \r\n ' + 
           'Favourite Colour: ' + data.favColour;

           // Convert the text to BLOB.
         const textToBLOB = new Blob([displayData], { type: 'text/plain' });
         const sFileName = 'ContactData.txt';	   // The file to save the data.

         let newLink = document.createElement("a");
         newLink.download = sFileName;

         if (window.webkitURL != null) {
             newLink.href = window.webkitURL.createObjectURL(textToBLOB);
         }
         else {
             newLink.href = window.URL.createObjectURL(textToBLOB);
             newLink.style.display = "none";
             document.body.appendChild(newLink);
         }

        newLink.click(); 

        }else {
          alert("Problem saving contact.")
        }
      })
}



function handle(e)
{
    const newdata = {...data}
    //  let error = '';

    // if (!e.target.value) {
    //     seterror(`${e.target.id} field cannot be empty`) ;
       
    //   }

    newdata[e.target.id] = e.target.value
    setData(newdata)
}

    return (
        <div >
                <form className="FormStyle" onSubmit={(e) => Submit(e)}>
                    <label htmlFor="firstName">First Name</label>
                    <input type="text" className="InputStyle" onChange={(e) => handle(e)} id="firstName" value={data.firstName} 
                    placeholder = "Your First Name .."></input>
                     {/* <span> {error}</span> */}
                    <label htmlFor="lastName">Last Name</label>
                    <input type="text" className="InputStyle" onChange={(e) => handle(e)} id="lastName" value={data.lastName} placeholder = "Your Last Name .."></input>
                    <label htmlFor="dateOfBirth">Date of Birth</label>
                    <input type="date" className="InputStyle" onChange={(e) => handle(e)} id="dateOfBirth" value={data.dateOfBirth} placeholder = "Birth Date"></input>
                    {/* <input type="text" onChange={(e) => handle(e)} id="favColour" value={data.favColour} placeholder = "colour"></input> */}

                    <label id="favColour">Favourite Colour </label>
                    <select  onChange={(e) => handle(e)} id="favColour">
                    <option key="Select" value="Select" >Select</option>
                    {colourOptions.map((option) => (
                    <option key={option.colour} value={option.colour}>{option.colour}</option>
                    ))}
                    </select>
                    
                            <button className="btn btn-default">submit</button>
                </form>


                <table>
                    <tbody>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Date of Birth</th>
                    <th>Favourite Colour</th>
                </tr>
               
               {contacts.slice(0,500).map(contact => (<tr>
                  <td>{contact.firstName}</td>
                  <td>{contact.lastName}</td>
                  <td>{contact.dateOfBirth}</td>
                  <td>{contact.favColour}</td>
                  </tr>))}
                  </tbody>
        </table>
        
        </div>
    )
}

